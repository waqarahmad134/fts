<img class="img-fluid" src="{{asset('public/assets/images/logo.png')}}" width="100" alt="logo"/>

